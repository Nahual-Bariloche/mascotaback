const accessKeyId = 'AKIAJVYP5ZMTPFSOMZCQ';
const secretAccessKey = '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';

module.exports = {
    accessKeyId: accessKeyId,
    secretAccessKey: secretAccessKey
};